/**
 * frontend/src/config.ts
 * Centralized API configuration
 */

export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';
